# oled_eye_display
Animated eyes on Oled display controlled with arduino nano, listening to command over usb connection.  Example with python.

Added support for arduino libraries U8G2 and adafruit. check the arduino folder.

Complete description
  
  https://www.intellar.ca/blog/animated-eye-oled
  
You can buy a hardware kit for this project and support the creation of new projects :

  https://www.intellar.ca/store
  
  
cycling of the animations:
arduino  https://www.youtube.com/watch?v=SV6P0KDAPRM

esp32    https://www.youtube.com/shorts/9WIiZSyQFy4


If you found this library useful in your project, please cite intellar.ca and considere giving it a star :star: 

You can also be the hero of the day by supporting my projects,  https://buymeacoffee.com/intellar


Example:
![face](https://github.com/intellar/oled_eye_display/assets/120540765/df08cd13-18a7-4cb7-ba06-3e5da848b927)
